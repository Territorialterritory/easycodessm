create definer = root@localhost trigger person_trigger_update
    after update
    on person
    for each row
begin set @x = "trigger UPDATE";
IF new.sex = 'M'
THEN
DELETE from person_ex where person_ex.id = new.id;
INSERT into person_ex SELECT * from person where person.id = new.id;
END IF;
end;

