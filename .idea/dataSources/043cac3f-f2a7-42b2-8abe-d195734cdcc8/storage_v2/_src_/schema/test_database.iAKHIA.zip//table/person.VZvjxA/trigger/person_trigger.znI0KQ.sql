create definer = root@localhost trigger person_trigger
    after insert
    on person
    for each row
begin set @x = "hello trigger";
IF new.sex = 'M'
THEN
INSERT INTO person_ex(id,name,sex) VALUES (New.id,new.`name`,new.sex);
END IF;
end;

