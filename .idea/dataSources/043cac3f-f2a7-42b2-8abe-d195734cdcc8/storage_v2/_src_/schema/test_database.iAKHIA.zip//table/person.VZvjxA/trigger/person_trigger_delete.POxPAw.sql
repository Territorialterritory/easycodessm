create definer = root@localhost trigger person_trigger_delete
    after delete
    on person
    for each row
begin set @x = "trigger DELETE";
DELETE FROM person_ex where person_ex.id = old.id;
end;

